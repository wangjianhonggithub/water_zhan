<?php

/**
 * @Author: Administrator
 * @Date:   2018-08-07 17:09:07
 * @Last Modified by:   Administrator
 * @Last Modified time: 2018-08-07 17:09:36
 */
namespace app\admin\model;
use think\Model;
use think\Db;

class OrderGoods extends Model
{


}