<?php
namespace app\admin\model;
use think\Model;
use think\Db;

class Putforward extends Model
{
    public $table = "water_Put_forward";
    //获取所有的数据
    public static function GetAll($where)
    {
    	$result = Putforward::where($where)
                            ->alias('p')
                            ->join('User u','u.id = p.uid')
                            ->order('p.PutStatus asc', 'p.createTime desc','p.id desc','p.status asc')
                            ->field('p.*,u.nickname')
                            // ->select();
                            ->paginate(15);

    	return $result;
    }

    //接口数据
    public static function GetWechatAll($userid)
    {
        $result = PutForward::all(['userid'=>$userid]);
        return $result;
    }
    
    //查找一条数据
    public static function GetOne($id)
    {
        $result = PutForward::alias('p')
                            ->join('User u','u.id = p.uid')
                            ->field('p.*,u.nickname')
                            ->find($id);

        $result['cardNo']    = '';
        $result['bank']      = '';
        $result['cusername'] = '';        

        if ($result) {
            $res = Db::name('card')->where('id',$result['cardId'])->find();
            if($res) {
                $result['cardNo'] = $res['cardNo'];
                $result['bank']   = $res['bank'];
                $result['cusername'] = $res['userName'];
            } 
        }

        return $result;
    }

    //多条件查询一条数据
    public static function GetCondOne($where)
    {
        $result = PutForward::where($where)->find();
        return $result;
    }

    //执行添加
    public static function doAction($id,$putStatus)
    {
        if (!$id && !$putStatus) {
            return  json_encode(["code"=>0,"meg"=>'参数不足']);
        }   


        // 执行修改状态操作
        try {

        if ($putStatus == 1) {
            
            $data   = PutForward::where('id',$id)->find();
            // 查询用户余额进行操作
            $money = Db::name('user')->where('id',$data['uid'])->value('money');

            // 判断余额
            if ($money < $data['money']) {
                return  json_encode(["code"=>0,"meg"=>'操作失败,余额不足']);
            }

            //进行 余额计算
            $new_money = $money - $data['money'];

            //入库操作
            Db::name('user')->where('id',$data['uid'])->update(['money'=>$new_money]);

                $result = PutForward::where('id',$id)->update(['putStatus'=>$putStatus,'status'=>1]);

            } else {
                $result = PutForward::where('id',$id)->update(['putStatus'=>$putStatus,'status'=>1]);
            }
            
            if ($result === false) {
                return  json_encode(["code"=>0,"meg"=>'操作失败']);
            }else{
                return json_encode(["code"=>1,"meg"=>"操作成功"]);
            }

        } catch (Exception $e) {
            return  json_encode(["code"=>0,"meg"=>'操作失败']);
        }
        

    }

    //执行修改
    public static function UpdateData($id,$data)
    {

    }

}
