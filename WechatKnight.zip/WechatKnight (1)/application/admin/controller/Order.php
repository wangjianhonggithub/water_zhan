<?php
namespace app\admin\controller;
use think\Loader;
use think\Db;
use app\admin\controller\Base;
use app\admin\model\Order as OrderModel;
class Order extends Base
{
	/**
	 * 轮播显示列表
	 * @Author   CarLos(wang)
	 * @DateTime 2018-06-06
	 * @Email    carlos0608@163.com
	 * @return   [type]             [description]
	 */
    public function index()
    {	
    	parent::CheckAdminLogin();
    	$data = OrderModel::GetAll();
    	return $this->fetch('Order/index',[
    		'list'=>$data,
    	]);
    }

    public function getInfo()
    {
        $info = OrderModel::GetOne($_GET['id']);
        return $this->fetch('Order/action',[
            'info'=>$info,
        ]);
    }
} 
